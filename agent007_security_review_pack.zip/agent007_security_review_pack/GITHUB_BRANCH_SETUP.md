# Creating the review branch

The GitHub integration rejected the automated branch-creation request with HTTP 403 (`Resource not accessible by integration`). No branch was created by that attempt.

If you have repository write access, create a branch in GitHub:
1. Open https://github.com/williamlockwoodjr-rgb/Min-mailbox
2. Select the branch dropdown currently showing `agent007-backpack-clipboard`.
3. Enter `security-007-hardening`.
4. Choose the option to create the branch from `agent007-backpack-clipboard`.
5. Confirm the new branch appears in the dropdown.

Do not change Render's configured branch yet. The test service should continue running its current revision while the security changes are reviewed and tested.

After the branch exists, the GitHub integration must also have permission to commit files to that branch before it can apply code changes directly.

# Mini Mailbox Security Test Checklist

**Current status:** not run. This is a proposed checklist, not a test report.

## Authentication and authorization
- [ ] Unauthenticated `POST /api/chat` is rejected.
- [ ] Authenticated user can use intended mailbox functions.
- [ ] Invalid/expired session is rejected.
- [ ] Private Agent 007 workspace functions are not available to anonymous visitors.
- [ ] Administrative or configuration actions require stronger authorization than ordinary chat.
- [ ] Session cookies, if used, have appropriate Secure, HttpOnly, and SameSite settings.
- [ ] Login endpoints have brute-force protections and safe error messages.

## Resource controls
- [ ] Request body size is capped before expensive parsing or API calls.
- [ ] Chat endpoint has per-user and fallback per-IP rate limits.
- [ ] Rate-limit state is shared across workers/instances in production.
- [ ] Concurrent request and upstream timeout behavior is bounded.
- [ ] OpenAI/API usage limits and billing alerts are configured where available.
- [ ] Repeated requests exceeding limits return a controlled `429` response.

## Secrets and privacy
- [ ] No API key appears in HTML, JavaScript, endpoint responses, repository files, or logs.
- [ ] Health endpoint does not reveal unnecessary configuration details to anonymous callers.
- [ ] Error messages sent to the browser do not expose stack traces or provider internals.
- [ ] Logs omit credentials, full prompts, user memory, and message bodies by default.
- [ ] Browser localStorage limitations are documented; sensitive content is not treated as securely stored.

## Code and dependencies
- [ ] `pip-audit` completes; each finding is triaged.
- [ ] Bandit completes; each finding is triaged.
- [ ] Automated tests cover auth, rate limits, input validation, and safe errors.
- [ ] OWASP ZAP scan is performed only against the authorized staging/test service.
- [ ] Tests are rerun after each code change.

## Release
- [ ] Code diff reviewed by the user.
- [ ] Test outputs and known limitations documented.
- [ ] Backup and rollback plan recorded.
- [ ] Explicit approval obtained for the exact service/revision.
- [ ] Only `Min-mailbox-2` is targeted; `Min-mailbox-1` remains untouched.
- [ ] Post-deployment smoke tests and logs reviewed.
